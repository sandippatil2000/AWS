﻿using Microsoft.Win32;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.Linq;
using System.Threading.Tasks;

namespace CustomAction
{
    [RunInstaller(true)]
    [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Demand)]
    public partial class Installer : System.Configuration.Install.Installer
    {
        public Installer()
        {
            InitializeComponent();
        }
        public override void Install(IDictionary stateSaver)
        {
            base.Install(stateSaver);

            var key = Registry.Users.OpenSubKey("S-1-5-18\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings", true);
            key.SetValue("test", "test", RegistryValueKind.String);
        }
        public override void Uninstall(IDictionary savedState)
        {
            base.Uninstall(savedState);
            var key = Registry.Users.OpenSubKey("S-1-5-18\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings", true);
            key.DeleteValue("test");
        }
    }
}
