﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;


namespace ConsoleApp1
{
    internal class Program
    {
        public static string GetUserSID(string userName)
        {
            try
            {
                NTAccount f = new NTAccount(userName);
                SecurityIdentifier s = (SecurityIdentifier)f.Translate(typeof(SecurityIdentifier));
                return s.ToString();
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        static void Main(string[] args)
        {


            //GetUserSID("Local_System");
            //var form = new HiddenForm();
            //form.ShowDialog();
            //Console.ReadLine();
            //HttpWebRequest myWebRequest = (HttpWebRequest)WebRequest.Create("http://www.microsoft.com");

            //WebResponse responseObject = null;
            //WebResponse response = myWebRequest.GetResponse();
            // Obtain the 'Proxy' of the  Default browser.  
            //IWebProxy proxy = myWebRequest.Proxy;

            //proxy.Credentials = new NetworkCredential();
            // Print the Proxy Url to the console.
            //if (proxy != null)
            //{
            //    Console.WriteLine("Proxy: {0}", proxy.GetProxy(myWebRequest.RequestUri));
            //    File.WriteAllText("d:\\log.txt", proxy.GetProxy(myWebRequest.RequestUri).ToString());

            //}
            //else
            //{
            //    Console.WriteLine("Proxy is null; no proxy will be used");
            //    File.WriteAllText("d:\\log.txt", proxy.GetProxy(myWebRequest.RequestUri).ToString());

            //}
            //Console.ReadLine();
        }
    }
}
